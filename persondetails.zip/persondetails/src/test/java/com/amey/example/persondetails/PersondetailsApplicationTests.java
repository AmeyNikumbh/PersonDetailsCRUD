package com.amey.example.persondetails;



import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.amey.example.persondetails.entity.Person;
import com.amey.example.persondetails.repository.PersonRepository;
import static org.junit.Assert.*;


@SpringBootTest
class PersondetailsApplicationTests {

	@Autowired
	PersonRepository personRepository;
	
	@Test
	void testSavePerson() {
		Person person = new Person(1,"Amey","Desai");
		personRepository.save(person);
		
	}
	
	@Test
	void testAllPersonsList() {
	
	    List<Person> personList = personRepository.findAll();
		assertFalse(personList.size() == 0);
		
	}

}
