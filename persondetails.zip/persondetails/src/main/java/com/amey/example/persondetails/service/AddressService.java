package com.amey.example.persondetails.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amey.example.persondetails.repository.AddressRepository;

@Service
@Transactional
public class AddressService {
	
	@Autowired
	private AddressRepository addressRepository;

	
	public void delete(Integer pId, Integer aId) {
		addressRepository.deleteAddressData(pId, aId);
	}

}
