package com.amey.example.persondetails.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.amey.example.persondetails.dto.PersonResponse;
import com.amey.example.persondetails.entity.Address;
import com.amey.example.persondetails.entity.Person;
import com.amey.example.persondetails.service.AddressService;
import com.amey.example.persondetails.service.PersonService;

@RestController
public class PersonController {

	@Autowired
	private PersonService personService;
	
	@Autowired
	private AddressService addressService;
	
	@PostMapping(value = { "/add/persondetails" }, consumes = "application/json", produces = "application/json")
	public ResponseEntity<PersonResponse> savePerson(@RequestBody Person person) {
		
		List<Address> addressList = new ArrayList<>();

		for (Address address : person.getAddressList()) {

			
			address.setPerson(person);
			addressList.add(address);
		}
		
		person.setAddressList(addressList);
		
		Person newPerson = personService.save(person);
		HttpHeaders responseHeaders = new HttpHeaders();
		return new ResponseEntity<> (PersonResponse.builder().firstName(newPerson.getFirstName()).lastName(newPerson.getLastName()).build(),responseHeaders,HttpStatus.OK);
	}
	
	@PutMapping("/person/{pId}/{aId}")
	public ResponseEntity<?> updatePersonDetails(@RequestBody Person person, @PathVariable Integer pId,@PathVariable Integer aId) {
	    try {
	    	
	    	addressService.delete(pId, aId);
	    	Person existPerson = personService.get(pId);
	    	
	    	List<Address> addressList = new ArrayList<>();

			for (Address address : person.getAddressList()) {

				
				address.setPerson(person);
				addressList.add(address);
			}
			
			person.setAddressList(addressList);
			person.setPersonId(pId);
	    	
			List<Address> addressList2 = person.getAddressList();
			List<Address> addressList1 = new ArrayList<Address>(addressList2);
			
			existPerson.setAddressList(addressList1);  
	    	existPerson.setFirstName(person.getFirstName());
	    	existPerson.setLastName(person.getLastName());
	    	
	    	personService.save(existPerson);
	        return new ResponseEntity<>(HttpStatus.OK);
	    } catch (NoSuchElementException e) {
	        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	    }      
	}
	
	@DeleteMapping("/remove/person/{personId}/{addressId}")
	public void deleteProjectsDetails(@PathVariable(name = "personId") Integer personId,@PathVariable(name = "addressId") Integer addressId) {
		
		addressService.delete(personId, addressId);
		personService.delete(personId);
	}
	
	@GetMapping("/person/all")
	public List<Person> getAllPersonlist() {
	    return personService.listAll();
	}
	
	@GetMapping("/person/count")
	public Integer getTotalPersonCount() {
		List<Person> personList =  personService.listAll();
		return personList.size();
		
	}
}
